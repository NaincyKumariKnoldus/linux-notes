#include <iostream>

int main()
{
  std::cout << "Thanks for viewing my code!";
  return 0;
}  
      
